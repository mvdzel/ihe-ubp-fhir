package ca.uhn.example.provider;

import java.util.Date;

import org.hl7.fhir.dstu3.model.Bundle;
import org.hl7.fhir.dstu3.model.Bundle.BundleEntryComponent;
import org.hl7.fhir.dstu3.model.Coding;
import org.hl7.fhir.dstu3.model.Device;
import org.hl7.fhir.dstu3.model.Device.DeviceUdiComponent;
import org.hl7.fhir.dstu3.model.Medication;
import org.hl7.fhir.dstu3.model.Patient;
import org.hl7.fhir.dstu3.model.Practitioner;
import org.hl7.fhir.dstu3.model.StringType;
import org.hl7.fhir.dstu3.model.UriType;

import ca.uhn.fhir.rest.annotation.Operation;
import ca.uhn.fhir.rest.annotation.OperationParam;

public class DecodeBarcodeOperation {

/*
 * Example device+patient: 
 * 		hrfString=0108712345670206172706208017101010101010101010
 * Example device+patient+practitioner: 
 * 		hrfString=010871234567020617270620801710101010101010101080180123456789012345678
 */
	
	@Operation(name = "$decode-barcode", idempotent = true)
	public Bundle decodeBarcodeOperation(@OperationParam(name = "hrfString") StringType hrfString,
			@OperationParam(name = "aidcString") StringType aidcString) {

		String hrf = hrfString.getValue();
		Device device = new Device();
		device.setUdi(new DeviceUdiComponent());
		device.getUdi().setCarrierHRF(hrf);
		Patient patient = new Patient();
		Practitioner practitioner = new Practitioner();
		Medication medication = new Medication();
		decode(hrf, device, patient, practitioner, medication);
		
		Bundle retVal = new Bundle();
		// Populate bundle with matching resources
		if (!device.isEmpty())
		{
			BundleEntryComponent entry = new BundleEntryComponent();
			entry.setResource(device);
			retVal.addEntry(entry);
		}
		if (!patient.isEmpty())
		{
			BundleEntryComponent entry = new BundleEntryComponent();
			entry.setResource(patient);
			retVal.addEntry(entry);
		}
		if (!practitioner.isEmpty())
		{
			BundleEntryComponent entry = new BundleEntryComponent();
			entry.setResource(practitioner);
			retVal.addEntry(entry);
		}		
		if (!medication.isEmpty())
		{
			BundleEntryComponent entry = new BundleEntryComponent();
			entry.setResource(medication);
			retVal.addEntry(entry);
		}		
		return retVal;
	}
	
	private void decode(String hrf, Device device, Patient patient, Practitioner practitioner, Medication medication)
	{
		// check if this is a EAN13 || GTIN-12
		if (hrf.length() == 13 || hrf.length() == 12)
		{
			medication.getCode().addCoding();
			medication.getCode().getCoding().get(0).setCode(hrf);
			return;
		}
		int pos = 0;
		while (pos+2 < hrf.length())
		{
			String ai = hrf.substring(pos, pos + 2);
			switch(ai)
			{
				case "01": // GTIN
					String deviceId = hrf.substring(pos + 2, pos + 16); 
					device.getUdi().setDeviceIdentifier(deviceId);
					pos += 16; 
					break;
				case "10": // Lotnumber
					device.setLotNumber(hrf.substring(pos + 2, pos + 8));
					pos += 8;
					break;
				case "17": // Expire Date
					String date = hrf.substring(pos + 2, pos + 8);
					int dd = Integer.parseInt(date.substring(4, 6));
					int mm = Integer.parseInt(date.substring(2, 4))-1;
					int yy = Integer.parseInt(date.substring(0, 2)) + 100;
					device.setExpirationDate(new Date(yy, mm, dd));
					pos += 8; 
					break;
				case "80": // GT**
					String type = hrf.substring(pos, pos + 4);
					String id = hrf.substring(pos + 4, pos + 22);
					switch (type)
					{
						case "8017": // GSRN Provider
							practitioner.addIdentifier();
							practitioner.getIdentifier().get(0).setSystemElement(new UriType("urn:gs1:gsrn-provider"));
							practitioner.getIdentifier().get(0).setValue(id);
							pos += 22; 
							break;
						case "8018": // GSRN Patient
							patient.addIdentifier();
							patient.getIdentifier().get(0).setSystemElement(new UriType("urn:gs1:gsrn-recipient"));
							patient.getIdentifier().get(0).setValue(id);
							pos += 22; 
							break;
						default:
							return;
					}
					break;
				default:
					return; 
			}
		}
	}
}
